"""One bounded poll, durable outbox and explicit operator-controlled delivery."""
from datetime import datetime, timedelta, timezone
import hashlib
import json
import time

from .config import validate_config
from .core import iso, make_alert, parse_time, preview_events
from .delivery import SMTPDelivery, DeliveryError, build_message
from .resend_delivery import ResendDelivery
from .source import AidpAuditSource, build_signer
from .state import FileStateStore, check_state_storage, StateError


class MonitorError(RuntimeError):
    pass


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _binding(c):
    original = _policy_binding(c)
    mode = c["monitor"].get("dedup_mode", "revision")
    return original if mode == "revision" else _digest([original, "dedup_mode", mode])


def _policy_binding(c):
    if c.get("resend", {}).get("enabled"):
        # Policy edits retain the cursor and already-queued immutable alerts.
        # Newly enabled rules apply to subsequent windows including overlap.
        return _digest({"environment": c["environment"],
                        "aidp": {k: c["aidp"].get(k) for k in ("endpoint", "api_resource", "datalake_id")},
                        "provider": "resend", "from_address": c["resend"]["from_address"],
                        "recipients": c["resend"]["recipients"]})
    # Never reuse a receipt/cursor across a different environment, ruleset or
    # delivery target. Changing those settings requires a new dedicated state.
    return _digest({k: c[k] for k in ("environment", "rules", "detail_fields", "change_fields", "actor_aliases")} |
                   {"aidp": {k: c["aidp"].get(k) for k in ("endpoint", "api_resource", "datalake_id")}} |
                   {"smtp": {k: c["smtp"].get(k) for k in ("host", "port", "tls", "from_address", "recipients")}})


def credential_resolver(config, aidputils):
    """Use existing AIDP credential-store entries, without persisting credentials."""
    def resolve(ref):
        try:
            entry = config["secret_refs"][ref]
            value = aidputils.secrets.get(entry["name"], key=entry["key"])
            if not isinstance(value, str) or not value:
                raise ValueError("Secret is unavailable")
            return value
        except Exception:
            raise MonitorError("Credential lookup failed; check configured references and access") from None
    return resolve


def create_source(config, secret_resolver=None):
    return AidpAuditSource(config, build_signer(config, secret_resolver=secret_resolver))


def _fetch(config, source, start, end, secret_resolver):
    if source is not None:
        return source.fetch(start, end)  # injected sources belong to the caller
    owned = create_source(config, secret_resolver)
    try:
        return owned.fetch(start, end)
    finally:
        owned.close()


def create_store(config, secret_resolver=None):
    s = config["state"]
    if s["backend"] == "file":
        check_state_storage(s["path"])
        return FileStateStore(s["path"], max_bytes=s.get("max_bytes", 5242880))
    raise MonitorError("Unsupported state backend")


def _clock(now):
    now = now or datetime.now(timezone.utc)
    if now.tzinfo is None:
        raise MonitorError("now must be timezone-aware")
    return now.astimezone(timezone.utc)


def preview_once(config, *, source=None, secret_resolver=None, now=None, emit=print):
    """Read real audits and print matches; does not even open state or SMTP."""
    c = validate_config(config)
    end = _clock(now) - timedelta(seconds=c["monitor"]["ingestion_delay_seconds"])
    start = end - timedelta(minutes=c["monitor"]["initial_lookback_minutes"])
    emit(f"Preview audit window: {iso(start)} to {iso(end)}. No state updates or email.")
    return preview_events(_fetch(c, source, start, end, secret_resolver), c, emit=emit)


def _check_state(data, binding):
    if data.get("binding") not in (None, binding):
        raise MonitorError("State belongs to a different source/rules/delivery configuration; use a NEW state path/object")
    if data.get("binding") is None and (data["cursor"] or data["events"] or data["deliveries"]):
        raise MonitorError("Existing nonempty state has no configuration binding; refusing to adopt it")
    for delivery in data["deliveries"].values():
        if delivery.get("status") not in {"pending", "sending", "uncertain", "accepted"}:
            raise MonitorError("Unknown delivery state; manual investigation required")
        if delivery.get("event_key") not in data["events"]:
            raise MonitorError("Delivery references a missing alert; refusing to discard it")
        if delivery["status"] in {"sending", "uncertain"}:
            raise MonitorError("Relay acceptance is uncertain for a saved delivery. Inspect state and provider logs, then resolve_delivery; no automatic resend")


def _prune(data, retention_days):
    if not data["cursor"]:
        return
    cutoff = parse_time(data["cursor"]) - timedelta(days=retention_days)
    pending_keys = {d["event_key"] for d in data["deliveries"].values() if d["status"] != "accepted"}
    expired = {key for key, alert in data["events"].items()
               if key not in pending_keys and parse_time(alert["event"]["timestamp_utc"]) < cutoff}
    data["events"] = {key: alert for key, alert in data["events"].items() if key not in expired}
    data["deliveries"] = {key: item for key, item in data["deliveries"].items() if item["event_key"] not in expired}
    return len(expired)


def deliver_once(config, *, confirm_send=False, secret_resolver=None, source=None,
                 store=None, sender=None, now=None, emit=print):
    """Send with configuration and runtime opt-ins, using a durable outbox.

    Accepted messages are acknowledged per recipient. Interrupted/ambiguous
    sends require human resolution. Resend keys expire; SMTP has no dedup contract.
    """
    if confirm_send is not True:
        raise MonitorError("Email requires confirm_send=True as well as an enabled email provider")
    c = validate_config(config, for_delivery=True)
    m = c["monitor"]
    now = _clock(now)
    end_available = now - timedelta(seconds=m["ingestion_delay_seconds"])
    provider = "resend" if c.get("resend", {}).get("enabled") else "smtp"
    email = c[provider]
    # Validate delivery settings BEFORE fetching audits or writing state.
    real_sender = (ResendDelivery(email, secret_resolver) if provider == "resend"
                   else SMTPDelivery(email, secret_resolver))
    sender = sender if sender is not None else real_sender
    store = store if store is not None else create_store(c, secret_resolver)
    accepted, errors = 0, 0
    with store.locked() as tx:
        data = tx.data
        binding = _binding(c)
        _check_state(data, binding)
        cursor = parse_time(data["cursor"]) if data["cursor"] else end_available - timedelta(minutes=m["initial_lookback_minutes"])
        if cursor > end_available:
            raise MonitorError("Checkpoint is ahead of the available time; verify clock and ingestion-delay setting")
        if (end_available - cursor).total_seconds() > m["max_catchup_hours"] * 3600:
            raise MonitorError("Catch-up gap exceeds configured maximum; increase it within audit retention, do not reset the checkpoint")
        end = min(end_available, cursor + timedelta(minutes=m["window_minutes"]))
        start = cursor - timedelta(seconds=m["overlap_seconds"]) if data["cursor"] else cursor
        raw_events = _fetch(c, source, start, end, secret_resolver)  # no partial checkpoint
        alerts = []
        observed = {}
        for raw in raw_events:
            event, alert = make_alert(raw, c)
            label = "/".join((event["object_type"], event["operation"], event["status"]))
            observed[label] = observed.get(label, 0) + 1
            if not start <= parse_time(event["timestamp_utc"]) <= end:
                raise MonitorError("Source returned an event outside the requested window")
            if alert:
                # Stable source IDs identify events even when their payload/status
                # is later revised. No-ID records fall back to the full fingerprint.
                event_key = (_digest(["source_event_id", raw["eventId"]])
                             if m["dedup_mode"] == "event_id" and raw.get("eventId")
                             else event["key"])
                alerts.append((event_key, alert))
        data["binding"] = binding
        already_accepted = {key for key, value in data["deliveries"].items() if value["status"] == "accepted"}
        matched_deliveries = set()
        for event_key, alert in alerts:
            data["events"].setdefault(event_key, alert)
            for recipient in email["recipients"]:
                key = _digest([binding, event_key, recipient])
                matched_deliveries.add(key)
                data["deliveries"].setdefault(key, {
                    "event_key": event_key, "recipient": recipient, "status": "pending", "attempts": 0,
                    "message_id": f"<{key}@aidp-audit-alerts.invalid>"})
        pending = [key for key, value in data["deliveries"].items() if value["status"] == "pending"]
        if len(pending) > m["max_pending_deliveries"]:
            raise MonitorError("Pending queue exceeds limit; no checkpoint advanced. Investigate email/capacity")
        data["cursor"] = iso(end)
        pruned = _prune(data, m["dedup_retention_days"])
        tx.save()  # atomic checkpoint AND outbox; no notification can be lost after cursor advances
        for key in pending[:m["max_deliveries_per_cycle"]]:
            item = data["deliveries"][key]
            alert = data["events"][item["event_key"]]
            message = build_message(alert["subject"], alert["body"], item["message_id"], email["from_address"], item["recipient"])
            item.update(status="sending", attempts=item["attempts"] + 1, last_attempt_utc=iso(now))
            tx.save()  # crash after this point is ambiguous, never blindly resend
            try:
                receipt = sender.send(message, item["recipient"])
            except DeliveryError as exc:
                item["status"] = "uncertain" if exc.acceptance_unknown else "pending"
                item["last_error"] = exc.category
                tx.save()
                errors += 1
                emit(f"Email not confirmed: delivery={key}, category={exc.category}, status={item['status']}")
            except Exception:
                item.update(status="uncertain", last_error="unexpected_delivery_error")
                tx.save()
                raise MonitorError("Unexpected delivery error; acceptance uncertain. Inspect saved delivery state") from None
            else:
                item.update(status="accepted", accepted_at_utc=iso(now))
                if provider == "resend" and isinstance(receipt, str):
                    item["provider_email_id"] = receipt
                item.pop("last_error", None)
                tx.save()  # failure leaves a durable 'sending' record, not a false receipt
                accepted += 1
        outstanding = sum(item["status"] != "accepted" for item in data["deliveries"].values())
        result = {"mode": "email", "provider": provider, "fetched": len(raw_events), "matched": len(alerts), "email_accepted": accepted,
                  "matched_unique": len({key for key, _ in alerts}),
                  "already_accepted": len(matched_deliveries & already_accepted),
                  "window_start_utc": iso(start), "observed_event_types": observed,
                  "pending_or_uncertain": outstanding, "errors": errors, "cursor_utc": data["cursor"],
                  "catchup_seconds_remaining": max(0, int((end_available - end).total_seconds())),
                  "expired_receipts_pruned": pruned}
        if provider == "smtp":
            result["smtp_accepted"] = accepted
        emit(json.dumps(result, sort_keys=True))
        if errors:
            raise MonitorError("Email failures remain in durable state; this cycle is FAILED, not successful")
        return result


def run_scheduled(config, *, max_cycles=96, confirm_send=False, secret_resolver=None,
                  source=None, store=None, sender=None, now=None, emit=print):
    """Drain bounded windows/outbox through a fixed invocation cutoff, then exit.

    Schedule this externally. A delayed invocation catches up from its saved
    cursor, rather than dropping everything older than the latest hour. The
    durable outbox owns pending sends even when its read cursor has advanced.
    """
    if confirm_send is not True:
        raise MonitorError("Scheduled email requires confirm_send=True")
    if type(max_cycles) is not int or not 1 <= max_cycles <= 10000:
        raise MonitorError("max_cycles must be an integer from 1 to 10000")
    c = validate_config(config, for_delivery=True)
    cutoff = _clock(now)
    totals = {"cycles": 0, "email_accepted": 0, "already_accepted_observations": 0}
    for cycle in range(max_cycles):
        result = deliver_once(c, confirm_send=True, secret_resolver=secret_resolver,
                              source=source, store=store, sender=sender, now=cutoff, emit=emit)
        totals["cycles"] = cycle + 1
        totals["email_accepted"] += result["email_accepted"]
        totals["already_accepted_observations"] += result["already_accepted"]
        if not result["catchup_seconds_remaining"] and not result["pending_or_uncertain"]:
            summary = {"mode": "scheduled_email", "status": "complete", **totals,
                       "run_cutoff_utc": iso(cutoff), "cursor_utc": result["cursor_utc"]}
            emit(json.dumps(summary, sort_keys=True))
            return summary
    raise MonitorError("Scheduled run reached max_cycles with unfinished catch-up or queued email. "
                       "Progress is saved; retry or increase bounds without resetting state.")


def resolve_delivery(config, delivery_id, resolution, *, confirm=False, store=None, secret_resolver=None):
    """Operator-only resolution AFTER checking relay logs; never called by a loop.

    resolution='accepted' records confirmed acceptance, 'retry' authorizes a
    possible duplicate. This changes only this monitor's dedicated state.
    """
    if confirm is not True or resolution not in {"accepted", "retry"}:
        raise MonitorError("Explicit confirm=True and resolution accepted|retry required")
    c = validate_config(config, for_delivery=True)
    store = store if store is not None else create_store(c, secret_resolver)
    with store.locked() as tx:
        if tx.data.get("binding") != _binding(c):
            raise MonitorError("State configuration does not match")
        item = tx.data["deliveries"].get(delivery_id)
        if not item or item["status"] not in {"sending", "uncertain"}:
            raise MonitorError("Delivery is not awaiting operator resolution")
        item.update(status="accepted" if resolution == "accepted" else "pending",
                    operator_resolution=resolution, resolved_at_utc=iso(datetime.now(timezone.utc)))
        tx.save()


def run_monitor(config, *, max_cycles=1, confirm_send=False, secret_resolver=None, emit=print):
    """Default one preview. Use max_cycles=None explicitly for a continuous run.

    Any failed cycle propagates and stops. External scheduling must alert on a
    failed/stale monitor; this process cannot guarantee its own failure email.
    """
    if max_cycles is not None and (type(max_cycles) is not int or max_cycles < 1):
        raise MonitorError("max_cycles must be positive or None")
    if type(confirm_send) is not bool:
        raise MonitorError("confirm_send must be the boolean True or False, not a string or number")
    c = validate_config(config, for_delivery=confirm_send is True)
    cycle = 0
    while max_cycles is None or cycle < max_cycles:
        began = time.monotonic()
        if confirm_send:
            deliver_once(c, confirm_send=True, secret_resolver=secret_resolver, emit=emit)
        else:
            preview_once(c, secret_resolver=secret_resolver, emit=emit)
        cycle += 1
        if max_cycles is None or cycle < max_cycles:
            time.sleep(max(0, c["monitor"]["poll_interval_seconds"] - (time.monotonic() - began)))
