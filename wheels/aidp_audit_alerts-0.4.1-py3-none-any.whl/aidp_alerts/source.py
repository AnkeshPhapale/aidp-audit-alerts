"""Read-only, bounded AIDP audit search using OCI API-key request signing.

The notebook uses the legacy ``/20240831/dataLakes`` API. Deployments using
``/20260430`` must explicitly set ``api_resource: aiDataPlatforms`` instead.
There is no automatic endpoint fallback and no call to manageAuditLogs.

Current public contract (query pagination; JSON ``items`` response):
https://docs.oracle.com/en/cloud/paas/ai-data-platform/aiwap/op-aidataplatforms-aidataplatformid-actions-searchauditlogs-post.html
API-key signing and in-memory private keys:
https://docs.oracle.com/en-us/iaas/tools/python/latest/api/signing.html
"""

from __future__ import annotations

from datetime import datetime, timezone
import math
import random
import time
import warnings
from urllib.parse import quote, urlsplit

import oci
import requests


class AuditSourceError(RuntimeError):
    """Safe diagnostic: never includes response bodies, credentials, or URLs."""


def _section(config: dict, name: str) -> dict:
    if not isinstance(config, dict) or not isinstance(config.get(name), dict):
        raise AuditSourceError(f"Configuration must contain a {name} object")
    return config[name]


def _required_string(config: dict, name: str) -> str:
    value = config.get(name)
    if not isinstance(value, str) or not value.strip():
        raise AuditSourceError(f"A nonempty {name} configuration value is required")
    return value


def _integer(config: dict, name: str, default: int, maximum: int) -> int:
    value = config.get(name, default)
    if type(value) is not int or not 1 <= value <= maximum:
        raise AuditSourceError(f"{name} must be an integer between 1 and {maximum}")
    return value


def _api_key_signer(signer):
    # SecurityTokenSigner and resource/instance-principal signers are distinct
    # from Signer. Do not silently pick auth from the execution environment.
    if not isinstance(signer, oci.signer.Signer):
        raise AuditSourceError("An OCI API-key Signer is required; token/principal auth is unsupported")
    return signer


def build_signer(config: dict, *, secret_resolver=None):
    """Build an API-key signer without printing or persisting any secret.

    ``config['oci']['auth']`` is ``config_file`` (existing OCI profile) or
    ``credential_store`` (tenancy/user/fingerprint + private_key_ref and optional
    passphrase_ref). The caller's ``secret_resolver(ref) -> str`` retrieves an
    AIDP Credential Store secret at point of use; this module never writes it.
    A pre-built API-key signer may instead be passed to ``AidpAuditSource``.
    """
    settings = _section(config, "oci")
    mode = settings.get("auth", "config_file")
    if mode not in {"config_file", "credential_store"}:
        raise AuditSourceError("oci.auth must be config_file or credential_store (API-key only)")
    if any(key in settings for key in ("private_key", "private_key_content", "passphrase", "pass_phrase", "security_token_file")):
        raise AuditSourceError("Inline credentials/token auth are forbidden; use secret references")
    try:
        if mode == "config_file":
            path = _required_string(settings, "config_file")
            profile = settings.get("profile", "DEFAULT")
            if not isinstance(profile, str) or not profile.strip():
                raise AuditSourceError("oci.profile must be a nonempty string")
            profile_config = oci.config.from_file(file_location=path, profile_name=profile)
            if profile_config.get("security_token_file") or profile_config.get("authentication_type", "API_KEY").upper() != "API_KEY":
                raise AuditSourceError("Selected OCI profile is not an API-key profile")
            oci.config.validate_config(profile_config)
            result = oci.signer.Signer(
                tenancy=profile_config["tenancy"], user=profile_config["user"],
                fingerprint=profile_config["fingerprint"],
                private_key_file_location=profile_config["key_file"],
                pass_phrase=profile_config.get("pass_phrase"),
            )
        else:
            tenancy = _required_string(settings, "tenancy")
            user = _required_string(settings, "user")
            fingerprint = _required_string(settings, "fingerprint")
            key_ref = _required_string(settings, "private_key_ref")
            if not callable(secret_resolver):
                raise AuditSourceError("credential_store requires a secret_resolver callable")
            key = secret_resolver(key_ref)
            passphrase = None
            if settings.get("passphrase_ref") is not None:
                passphrase = secret_resolver(_required_string(settings, "passphrase_ref"))
            if not isinstance(key, str) or not key or (passphrase is not None and not isinstance(passphrase, str)):
                raise AuditSourceError("Secret resolver must return secret text")
            result = oci.signer.Signer(
                tenancy=tenancy, user=user, fingerprint=fingerprint,
                private_key_file_location=None, private_key_content=key,
                pass_phrase=passphrase,
            )
        return _api_key_signer(result)
    except AuditSourceError:
        raise
    except Exception:
        # SDK/secret-store exception strings can contain a path, key or token.
        raise AuditSourceError("Unable to construct OCI API-key signer; verify profile/secret references and permissions") from None


def _aware_utc(value: datetime) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise AuditSourceError("Audit query boundaries must be timezone-aware datetimes")
    return value.astimezone(timezone.utc)


def _event_time(event: dict) -> datetime:
    value = event.get("timeOfLog")
    if not isinstance(value, str):
        raise AuditSourceError("Audit result is missing a valid timeOfLog; collection is incomplete")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return _aware_utc(parsed)
    except (ValueError, TypeError, AuditSourceError):
        raise AuditSourceError("Audit result has an invalid timeOfLog; collection is incomplete") from None


def _page_token(response, body: dict):
    # The documented source is the header. Legacy notebook deployments also
    # return opcNextPage or nextPage in JSON. Never choose silently if any
    # supplied continuation sources disagree: dropping one can truncate a poll.
    tokens = [response.headers.get("opc-next-page"), body.get("opcNextPage"), body.get("nextPage")]
    for token in tokens:
        if token is not None and (not isinstance(token, str) or not token.strip() or len(token) > 1024):
            raise AuditSourceError("Audit response contains an invalid pagination token")
    supplied = [token for token in tokens if token is not None]
    if len(set(supplied)) > 1:
        raise AuditSourceError("Audit response pagination tokens disagree")
    return supplied[0] if supplied else None


class AidpAuditSource:
    """Fetch an inclusive UTC window completely or raise, never return partial data.

    Retries are limited to transport failures, HTTP 429 and transient 5xx errors.
    Each attempt is a new signed request, not an urllib3 replay of a signed
    request. Redirects are forbidden. Source output is unsanitized audit data:
    pass it through the alert normalizer/redactor before displaying or sending.
    """

    def __init__(self, config: dict, signer, session=None):
        settings = _section(config, "aidp")
        endpoint = _required_string(settings, "endpoint").rstrip("/")
        try:
            parts = urlsplit(endpoint)
            valid = (
                parts.scheme == "https" and parts.hostname and not parts.username
                and not parts.password and not parts.query and not parts.fragment
                and parts.port in (None, 443)
                and parts.path in ("/20240831", "/20260430")
                and not any(char.isspace() for char in endpoint)
            )
        except ValueError:
            valid = False
        if not valid:
            raise AuditSourceError("aidp.endpoint must be a trusted HTTPS API base ending /20240831 or /20260430, without credentials or query")
        resource = settings.get("api_resource", "dataLakes")
        if resource not in {"dataLakes", "aiDataPlatforms"}:
            raise AuditSourceError("aidp.api_resource must be dataLakes or aiDataPlatforms")
        expected = {"/20240831": "dataLakes", "/20260430": "aiDataPlatforms"}
        if expected[parts.path] != resource:
            raise AuditSourceError("aidp.api_resource does not match the configured API version")
        lake = _required_string(settings, "datalake_id")
        if len(lake) > 500 or any(char.isspace() for char in lake) or any(char in lake for char in "/?#"):
            raise AuditSourceError("aidp.datalake_id must be a single valid instance identifier")
        self._url = f"{endpoint}/{resource}/{quote(lake, safe='')}/actions/searchAuditLogs"
        self._signer = _api_key_signer(signer)
        self._max_pages = _integer(settings, "max_pages", 100, 10000)
        self._page_size = _integer(settings, "page_size", 100, 1000)
        self._max_events = _integer(settings, "max_events", 10000, 1000000)
        self._max_attempts = _integer(settings, "max_attempts", 3, 10)
        timeout = settings.get("request_timeout_seconds", 45)
        if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 300:
            raise AuditSourceError("request_timeout_seconds must be a finite number in (0, 300]")
        self._timeout = timeout
        self._owns_session = session is None
        self._session = requests.Session() if session is None else session
        if self._owns_session:
            # Avoid ambient proxy/netrc credentials. Explicit API-key signer is
            # the only auth source; trust roots remain the requests CA bundle.
            self._session.trust_env = False
        if isinstance(self._session, requests.Session):
            for adapter in self._session.adapters.values():
                if adapter.max_retries.total not in (0, False):
                    raise AuditSourceError("Session adapter retries must be disabled; retries must re-sign requests")

    def close(self):
        if self._owns_session:
            self._session.close()

    def _request_page(self, body: dict, params: dict):
        for attempt in range(self._max_attempts):
            try:
                response = self._session.post(
                    self._url, params=params, json=body, auth=self._signer,
                    headers={"Accept": "application/json"},
                    timeout=(min(10, self._timeout), self._timeout),
                    allow_redirects=False, verify=True,
                )
            except requests.RequestException:
                if attempt + 1 == self._max_attempts:
                    raise AuditSourceError("Audit search transport failure; retry limit reached, no checkpoint may advance") from None
            else:
                status = response.status_code
                if status == 200:
                    return response
                response.close()
                if status not in {429, 500, 502, 503, 504}:
                    raise AuditSourceError(f"Audit search failed with HTTP {status}; no checkpoint may advance")
                if attempt + 1 == self._max_attempts:
                    raise AuditSourceError(f"Audit search failed with HTTP {status}; retry limit reached, no checkpoint may advance")
            time.sleep(min(2 ** attempt + random.uniform(0, 0.25), 10))
        raise AuditSourceError("Audit search retry limit reached")  # Defensive unreachable.

    def fetch(self, start: datetime, end: datetime) -> list[dict]:
        start, end = _aware_utc(start), _aware_utc(end)
        if start >= end:
            raise AuditSourceError("Audit window start must be before end")
        body = {
            "timeBegin": start.isoformat().replace("+00:00", "Z"),
            "timeEnd": end.isoformat().replace("+00:00", "Z"),
            "sortBy": "time", "sortOrder": "ASC",
        }
        events = []
        scanned = excluded = 0
        seen_tokens = set()
        token = None
        for _ in range(self._max_pages):
            params = {"limit": self._page_size}
            if token is not None:
                params["page"] = token
            response = self._request_page(body, params)
            try:
                try:
                    document = response.json()
                except (ValueError, requests.RequestException):
                    raise AuditSourceError("Audit search returned invalid JSON; collection is incomplete") from None
                if not isinstance(document, dict) or not isinstance(document.get("items"), list):
                    raise AuditSourceError("Audit search response must contain an items list; collection is incomplete")
                page = document["items"]
                if any(not isinstance(event, dict) for event in page):
                    raise AuditSourceError("Audit search contains a malformed event; collection is incomplete")
                # Count every returned row, including rows excluded locally.
                scanned += len(page)
                if scanned > self._max_events:
                    raise AuditSourceError("Audit max_events exceeded; shorten the window or raise the bound before retrying")
                for event in page:
                    # The deployed API can return rows beyond timeEnd. Apply
                    # the exact window locally, but exhaust pagination even
                    # when an entire page lies outside it.
                    if start <= _event_time(event) <= end:
                        events.append(event)
                    else:
                        excluded += 1
                token = _page_token(response, document)
            finally:
                response.close()
            if token is None:
                if excluded:
                    warnings.warn(
                        f"Audit search excluded {excluded} of {scanned} returned rows "
                        "outside the requested UTC window; all pages were read.",
                        RuntimeWarning, stacklevel=2,
                    )
                return events
            if token in seen_tokens:
                raise AuditSourceError("Audit pagination repeated a token; collection is incomplete")
            seen_tokens.add(token)
        raise AuditSourceError("Audit max_pages exceeded; shorten the window or raise the bound before retrying")
