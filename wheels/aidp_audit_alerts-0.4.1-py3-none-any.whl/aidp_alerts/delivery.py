"""TLS-only, one-recipient SMTP delivery; never used by notebook preview mode.

Returning from ``send`` means the relay accepted DATA, not inbox delivery.
No SMTP retry is performed here: a lost response after DATA is ambiguous.
Secret values are fetched immediately before authentication and are never stored
in configuration, logs, generated messages, or exception messages.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, timezone
from email import policy
from email.message import EmailMessage
from email.utils import format_datetime
import math
import re
import smtplib
import ssl
import warnings


class DeliveryError(RuntimeError):
    """Safe delivery diagnostic; deliberately excludes server exception text."""

    def __init__(self, category: str, smtp_status: int | None = None,
                 acceptance_unknown: bool = False):
        self.category = category
        self.smtp_status = smtp_status
        self.acceptance_unknown = acceptance_unknown
        text = f"SMTP delivery failed: {category}"
        if smtp_status is not None:
            text += f" (status {smtp_status})"
        if acceptance_unknown:
            text += "; relay acceptance unknown; do not blindly retry"
        super().__init__(text)


_CONFIG_KEYS = frozenset({
    "enabled", "host", "port", "tls", "timeout_seconds", "from_address",
    "recipients", "username_ref", "password_ref", "ca_file",
})
_LOCAL_PART = re.compile(r"[A-Za-z0-9!#$%&'*+/=?^_`{|}~.-]+\Z")
_DOMAIN_LABEL = re.compile(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\Z")
_MESSAGE_ID = re.compile(r"<[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9.-]+>\Z")
_MAX_BODY_BYTES = 1024 * 1024


def _header(value: str, maximum: int) -> str:
    if (not isinstance(value, str) or not value or len(value) > maximum
            or any(ord(c) < 32 or ord(c) == 127 for c in value)):
        raise DeliveryError("invalid_header")
    return value


def _address(value: str) -> str:
    """Support bare ASCII addr-spec only, not display names or address lists."""
    _header(value, 254)
    if value.count("@") != 1 or not value.isascii():
        raise DeliveryError("invalid_address")
    local, domain = value.split("@")
    if (not local or len(local) > 64 or not _LOCAL_PART.fullmatch(local)
            or local.startswith(".") or local.endswith(".") or ".." in local
            or not domain or not all(_DOMAIN_LABEL.fullmatch(x) for x in domain.split("."))):
        raise DeliveryError("invalid_address")
    return value


def build_message(subject: str, body: str, message_id: str,
                  from_address: str, recipient: str) -> EmailMessage:
    """Build bounded plain-text mail. Caller supplies a stable Message-ID."""
    _header(subject, 512)
    _header(message_id, 254)
    if not _MESSAGE_ID.fullmatch(message_id):
        raise DeliveryError("invalid_message_id")
    _address(from_address)
    _address(recipient)
    if (not isinstance(body, str) or not body or "\x00" in body
            or len(body.encode("utf-8")) > _MAX_BODY_BYTES):
        raise DeliveryError("invalid_body")
    msg = EmailMessage(policy=policy.SMTP)
    msg["Subject"] = subject
    msg["From"] = from_address
    msg["To"] = recipient
    msg["Message-ID"] = message_id
    msg["Date"] = format_datetime(datetime.now(timezone.utc))
    msg.set_content(body, subtype="plain", charset="utf-8")
    return msg


class SMTPDelivery:
    """Explicit opt-in SMTP with certificate verification and required auth.

    Configuration has secret references, not username/password values. The
    resolver is supplied by the deployment's credential-store integration.
    All recipients must be configured in advance; each call sends to just one.
    """

    def __init__(self, smtp_config: dict, secret_resolver: Callable[[str], str]):
        if not isinstance(smtp_config, dict) or set(smtp_config) - _CONFIG_KEYS:
            raise DeliveryError("invalid_config")
        if type(smtp_config.get("enabled")) is not bool:
            raise DeliveryError("invalid_config")
        self._enabled = smtp_config["enabled"]
        self._resolver = secret_resolver
        self._config = dict(smtp_config)
        if not self._enabled:
            return
        required = _CONFIG_KEYS - {"ca_file"}
        if not required <= set(smtp_config) or not callable(secret_resolver):
            raise DeliveryError("invalid_config")
        host = smtp_config["host"]
        if (not isinstance(host, str) or not host or len(host) > 253
                or any(c.isspace() for c in host) or "/" in host or "@" in host
                or any(ord(c) < 32 or ord(c) == 127 for c in host)):
            raise DeliveryError("invalid_config")
        port = smtp_config["port"]
        timeout = smtp_config["timeout_seconds"]
        if type(port) is not int or not 1 <= port <= 65535:
            raise DeliveryError("invalid_config")
        if (type(timeout) not in (int, float) or not math.isfinite(timeout)
                or not 0 < timeout <= 300):
            raise DeliveryError("invalid_config")
        if smtp_config["tls"] not in ("starttls", "ssl"):
            raise DeliveryError("invalid_config")
        _address(smtp_config["from_address"])
        recipients = smtp_config["recipients"]
        if not isinstance(recipients, list) or not recipients or len(recipients) > 100:
            raise DeliveryError("invalid_config")
        for recipient in recipients:
            _address(recipient)
        if len(set(recipients)) != len(recipients):
            raise DeliveryError("invalid_config")
        self._config["recipients"] = tuple(recipients)
        for key in ("username_ref", "password_ref"):
            ref = smtp_config[key]
            if (not isinstance(ref, str) or not ref or len(ref) > 512
                    or any(c.isspace() or ord(c) < 32 for c in ref)):
                raise DeliveryError("invalid_config")
        ca_file = smtp_config.get("ca_file")
        if ca_file is not None and (not isinstance(ca_file, str) or not ca_file
                                    or "\x00" in ca_file or "\n" in ca_file or "\r" in ca_file):
            raise DeliveryError("invalid_config")

    def _tls_context(self) -> ssl.SSLContext:
        # Unlike create_default_context(), this does not honor SSLKEYLOGFILE:
        # SMTP credentials must not be recoverable from generated key-log files.
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        if self._config.get("ca_file"):
            context.load_verify_locations(cafile=self._config["ca_file"])
        else:
            context.load_default_certs()
        return context

    def send(self, message: EmailMessage, recipient: str) -> None:
        """Send exactly once; caller owns durable receipts and retry policy."""
        if not self._enabled:
            raise DeliveryError("disabled")
        _address(recipient)
        if recipient not in self._config["recipients"]:
            raise DeliveryError("recipient_not_configured")
        if (not isinstance(message, EmailMessage) or message.is_multipart()
                or message.get_content_type() != "text/plain"
                or len(message.get_all("Subject", [])) != 1
                or len(message.get_all("Message-ID", [])) != 1):
            raise DeliveryError("invalid_message")
        # Rebuild the minimal allowed header set. To/Cc/Bcc/Resent headers and
        # a caller-supplied From cannot redirect mail or expose other recipients.
        try:
            outgoing = build_message(str(message["Subject"]), message.get_content(),
                                     str(message["Message-ID"]),
                                     self._config["from_address"], recipient)
        except DeliveryError:
            raise
        except Exception:
            raise DeliveryError("invalid_message") from None
        client = None
        sending = False
        username = password = None
        try:
            context = self._tls_context()
            if self._config["tls"] == "ssl":
                client = smtplib.SMTP_SSL(self._config["host"], self._config["port"],
                                          timeout=self._config["timeout_seconds"], context=context)
            else:
                client = smtplib.SMTP(self._config["host"], self._config["port"],
                                      timeout=self._config["timeout_seconds"])
                code, _ = client.ehlo()
                if code != 250:
                    raise DeliveryError("ehlo_rejected", code)
                # starttls raises if unsupported. No plaintext fallback.
                client.starttls(context=context)
            code, _ = client.ehlo()
            if code != 250:
                raise DeliveryError("ehlo_rejected", code)
            try:
                username = self._resolver(self._config["username_ref"])
                password = self._resolver(self._config["password_ref"])
                if (not isinstance(username, str) or not username
                        or not isinstance(password, str) or not password):
                    raise ValueError()
            except Exception:
                raise DeliveryError("secret_resolution") from None
            client.login(username, password)
            username = password = None
            sending = True
            refused = client.send_message(outgoing, from_addr=self._config["from_address"],
                                           to_addrs=[recipient])
            if refused:
                raise DeliveryError("recipient_refused")
        except DeliveryError:
            raise
        except smtplib.SMTPAuthenticationError as exc:
            raise DeliveryError("authentication", exc.smtp_code) from None
        except smtplib.SMTPRecipientsRefused:
            raise DeliveryError("recipient_refused") from None
        except smtplib.SMTPSenderRefused as exc:
            raise DeliveryError("sender_refused", exc.smtp_code) from None
        except smtplib.SMTPDataError as exc:
            raise DeliveryError("data_rejected", exc.smtp_code) from None
        except ssl.SSLError:
            raise DeliveryError("tls", acceptance_unknown=sending) from None
        except TimeoutError:
            raise DeliveryError("timeout", acceptance_unknown=sending) from None
        except smtplib.SMTPException:
            raise DeliveryError("smtp", acceptance_unknown=sending) from None
        except OSError:
            raise DeliveryError("transport", acceptance_unknown=sending) from None
        except Exception:
            raise DeliveryError("unexpected", acceptance_unknown=sending) from None
        finally:
            username = password = None
            if client is not None:
                # smtplib retains auth values on the client instance after login.
                client.user = client.password = None
                try:
                    # DATA acceptance is the acknowledgement boundary; a QUIT
                    # failure must not turn accepted mail into an apparent retry.
                    client.close()
                except Exception:
                    try:
                        warnings.warn("SMTP socket cleanup failed; delivery outcome unchanged",
                                      RuntimeWarning, stacklevel=2)
                    except RuntimeWarning:
                        # A deployment may promote warnings to exceptions.
                        # Even then, cleanup cannot undo a relay DATA receipt.
                        pass
