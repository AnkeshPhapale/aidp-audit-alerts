"""Resend HTTPS sender for the durable outbox; credentials never enter state.

Retries use a stable idempotency key. Ambiguous acceptance still requires
operator reconciliation: Resend's deduplication window is only 24 hours.
"""
from copy import deepcopy
from email.message import EmailMessage
import hashlib
import math
import time

import requests

from .delivery import DeliveryError, _address, build_message


class ResendDelivery:
    def __init__(self, config, secret_resolver):
        allowed = {"enabled", "from_address", "recipients", "api_key_ref", "timeout_seconds", "min_interval_seconds"}
        if (not isinstance(config, dict) or set(config) - allowed
                or config.get("enabled") is not True or not callable(secret_resolver)):
            raise DeliveryError("invalid_resend_config")
        _address(config.get("from_address"))
        recipients = config.get("recipients")
        if not isinstance(recipients, list) or not 1 <= len(recipients) <= 100:
            raise DeliveryError("invalid_resend_config")
        for recipient in recipients:
            _address(recipient)
        if len(set(recipients)) != len(recipients):
            raise DeliveryError("invalid_resend_config")
        ref = config.get("api_key_ref")
        if not isinstance(ref, str) or not ref or any(c.isspace() or ord(c) < 32 for c in ref):
            raise DeliveryError("invalid_resend_config")
        timeout = config.get("timeout_seconds", 30)
        if type(timeout) not in (int, float) or not math.isfinite(timeout) or not 0 < timeout <= 300:
            raise DeliveryError("invalid_resend_config")
        self.config = deepcopy(config)
        self.timeout = timeout
        self.resolver = secret_resolver
        interval = config.get("min_interval_seconds", 0)
        if type(interval) not in (int, float) or not math.isfinite(interval) or not 0 <= interval <= 60:
            raise DeliveryError("invalid_resend_config")
        self.min_interval = interval
        self._last_request = None

    def send(self, message, recipient):
        if recipient not in self.config["recipients"]:
            raise DeliveryError("recipient_not_configured")
        if (not isinstance(message, EmailMessage) or message.is_multipart()
                or message.get_content_type() != "text/plain"
                or len(message.get_all("Subject", [])) != 1
                or len(message.get_all("Message-ID", [])) != 1):
            raise DeliveryError("invalid_message")
        outgoing = build_message(str(message["Subject"]), message.get_content(),
                                 str(message["Message-ID"]), self.config["from_address"], recipient)
        payload = {"from": self.config["from_address"], "to": [recipient],
                   "subject": str(outgoing["Subject"]), "text": outgoing.get_content()}
        key = "aidp/" + hashlib.sha256(str(outgoing["Message-ID"]).encode()).hexdigest()
        try:
            api_key = self.resolver(self.config["api_key_ref"])
            if not isinstance(api_key, str) or not api_key or any(c.isspace() for c in api_key):
                raise ValueError()
        except Exception:
            raise DeliveryError("resend_secret_resolution") from None
        # A private session disables ambient netrc/proxy credentials and HTTP retries.
        with requests.Session() as session:
            session.trust_env = False
            try:
                if self._last_request is not None:
                    delay = self.min_interval - (time.monotonic() - self._last_request)
                    if delay > 0:
                        time.sleep(delay)
                self._last_request = time.monotonic()
                response = session.post(
                    "https://api.resend.com/emails", json=payload,
                    headers={"Authorization": "Bearer " + api_key, "Idempotency-Key": key},
                    timeout=(min(10, self.timeout), self.timeout), allow_redirects=False,
                )
            except requests.RequestException:
                raise DeliveryError("resend_transport", acceptance_unknown=True) from None
            finally:
                api_key = None
            try:
                if response.status_code != 200:
                    # 5xx / conflicts can be ambiguous. Never silently replay them.
                    raise DeliveryError(f"resend_http_{response.status_code}",
                                        acceptance_unknown=response.status_code >= 500 or response.status_code == 409)
                try:
                    receipt = response.json()
                except ValueError:
                    raise DeliveryError("resend_invalid_receipt", acceptance_unknown=True) from None
                if (not isinstance(receipt, dict) or not isinstance(receipt.get("id"), str)
                        or not receipt["id"] or len(receipt["id"]) > 100
                        or any(c not in "0123456789abcdefABCDEF-" for c in receipt["id"])):
                    raise DeliveryError("resend_invalid_receipt", acceptance_unknown=True)
                return receipt["id"]
            finally:
                response.close()
