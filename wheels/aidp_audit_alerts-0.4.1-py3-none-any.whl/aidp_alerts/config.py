"""Non-secret configuration; validation never prints configured values."""
from copy import deepcopy
import json
from pathlib import Path
from zoneinfo import ZoneInfo


class ConfigError(ValueError):
    pass


def load_config(path):
    with Path(path).open(encoding="utf-8-sig") as handle:
        value = json.load(handle)
    return validate_config(value)


def _text(value, name):
    if not isinstance(value, str) or not value.strip() or any(ord(c) < 32 for c in value):
        raise ConfigError(f"{name} must be a non-empty single-line string")


def _integer(value, name, minimum=1, maximum=1000000):
    if type(value) is not int or not minimum <= value <= maximum:
        raise ConfigError(f"{name} must be an integer in [{minimum}, {maximum}]")


def _exact_keys(value, allowed, name):
    if not isinstance(value, dict) or set(value) - set(allowed):
        raise ConfigError(f"{name} contains unknown keys or is not an object")


def validate_config(config, *, for_delivery=False):
    c = deepcopy(config)
    _exact_keys(c, ["environment", "timezone", "aidp", "oci", "monitor", "state", "smtp", "resend",
                    "secret_refs", "actor_aliases", "detail_fields", "change_fields", "rules"], "config")
    for key in ("environment", "timezone"):
        _text(c.get(key), key)
    try:
        ZoneInfo(c["timezone"])
    except (KeyError, ValueError):
        raise ConfigError("timezone must be an installed IANA timezone; install tzdata") from None
    for key in ("aidp", "oci", "monitor", "state", "smtp"):
        if not isinstance(c.get(key), dict):
            raise ConfigError(f"{key} must be an object")
    _exact_keys(c["aidp"], ["endpoint", "api_resource", "datalake_id", "request_timeout_seconds",
                            "max_pages", "page_size", "max_events", "max_attempts"], "aidp")
    _exact_keys(c["oci"], ["auth", "config_file", "profile", "region", "tenancy", "user", "fingerprint",
                           "private_key_ref", "passphrase_ref"], "oci")
    _exact_keys(c["state"], ["backend", "path", "durable_confirmed", "max_bytes"], "state")
    if c["state"].get("backend") != "file":
        raise ConfigError("state.backend must be file; configure a kernel-readable workspace checkpoint path")
    _text(c["state"].get("path"), "state.path")
    for key in ("endpoint", "datalake_id"):
        _text(c["aidp"].get(key), f"aidp.{key}")
    m = c["monitor"]
    defaults = dict(initial_lookback_minutes=15, overlap_seconds=600, ingestion_delay_seconds=60,
                    window_minutes=15, max_catchup_hours=72, poll_interval_seconds=60,
                    max_deliveries_per_cycle=100, dedup_retention_days=30, max_pending_deliveries=20000)
    _exact_keys(m, [*defaults, "dedup_mode"], "monitor")
    m.setdefault("dedup_mode", "revision")
    if m["dedup_mode"] not in ("revision", "event_id"):
        raise ConfigError("monitor.dedup_mode must be revision or event_id")
    for key, value in defaults.items():
        m.setdefault(key, value)
        _integer(m[key], f"monitor.{key}", 0 if key == "ingestion_delay_seconds" else 1)
    if m["dedup_retention_days"] * 86400 <= max(m["overlap_seconds"], m["max_catchup_hours"] * 3600):
        raise ConfigError("dedup retention must exceed overlap and maximum catch-up duration")
    if m["max_catchup_hours"] * 60 < m["initial_lookback_minutes"]:
        raise ConfigError("max_catchup_hours must cover initial lookback")
    rules = c.get("rules")
    if not isinstance(rules, list) or not rules:
        raise ConfigError("rules must be a non-empty list")
    seen = set()
    for r in rules:
        _exact_keys(r, ["id", "enabled", "severity", "object_types", "operations", "statuses", "object_name_globs"], "rule")
        _text(r.get("id"), "rule.id")
        if r["id"] in seen:
            raise ConfigError("rule IDs must be unique")
        seen.add(r["id"])
        if type(r.get("enabled")) is not bool:
            raise ConfigError("rule.enabled must be true or false")
        if r.get("severity") not in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
            raise ConfigError("rule.severity must be CRITICAL, HIGH, MEDIUM or LOW")
        for key in ("object_types", "operations", "statuses", "object_name_globs"):
            if key == "object_name_globs" and key not in r:
                continue
            if not isinstance(r.get(key), list) or not r[key]:
                raise ConfigError(f"rule.{key} must be a non-empty list; use ['*'] to match all")
            for item in r[key]:
                _text(item, f"rule.{key}")
            if key != "object_name_globs":
                r[key] = [v.upper() for v in r[key]]
    for key in ("actor_aliases", "detail_fields", "secret_refs"):
        c.setdefault(key, {})
        if not isinstance(c[key], dict):
            raise ConfigError(f"{key} must be an object")
    for key, value in c["actor_aliases"].items():
        _text(key, "actor alias key")
        _text(value, "actor alias")
    for ref, entry in c["secret_refs"].items():
        _text(ref, "secret reference")
        _exact_keys(entry, ["name", "key"], "secret reference")
        _text(entry.get("name"), "credential name")
        _text(entry.get("key"), "credential key")
    for label, pointer in c["detail_fields"].items():
        _text(label, "detail label")
        _pointer(pointer)
    c.setdefault("change_fields", [])
    if not isinstance(c["change_fields"], list):
        raise ConfigError("change_fields must be a list")
    for field in c["change_fields"]:
        _exact_keys(field, ["label", "before", "after"], "change field")
        _text(field.get("label"), "change label")
        _pointer(field.get("before"))
        _pointer(field.get("after"))
    if type(c["smtp"].get("enabled")) is not bool:
        raise ConfigError("smtp.enabled must be true or false")
    # Reject accidental plaintext secrets even in preview mode.
    _exact_keys(c["smtp"], ["enabled", "host", "port", "tls", "timeout_seconds", "from_address",
                            "recipients", "username_ref", "password_ref", "ca_file"], "smtp")
    if "resend" in c:
        _exact_keys(c["resend"], ["enabled", "from_address", "recipients", "api_key_ref", "timeout_seconds", "min_interval_seconds"], "resend")
        if type(c["resend"].get("enabled")) is not bool:
            raise ConfigError("resend.enabled must be true or false")
    if c["smtp"]["enabled"] and c.get("resend", {}).get("enabled"):
        raise ConfigError("Enable only one email provider: SMTP or Resend")
    if for_delivery:
        if not c["smtp"]["enabled"] and not c.get("resend", {}).get("enabled"):
            raise ConfigError("Email is disabled; preview_events / preview_once never sends email")
        s = c["state"]
        if s.get("durable_confirmed") is not True:
            raise ConfigError("Confirm durable state storage before enabling email: state.durable_confirmed=true")
    return c


def _pointer(value):
    _text(value, "payload JSON pointer")
    if not value.startswith("/") or value == "/":
        raise ConfigError("payload mappings must be explicit JSON pointers to fields, not the entire payload")
