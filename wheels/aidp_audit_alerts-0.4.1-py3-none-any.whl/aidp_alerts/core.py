"""Audit normalization and explicit user-defined matching; no network or writes."""
from collections import Counter
from datetime import datetime, timezone
from fnmatch import fnmatchcase
import hashlib
import json
import re
from zoneinfo import ZoneInfo

from .config import validate_config

UNKNOWN = "NOT RECORDED"
SEVERITIES = {"LOW": 0, "MEDIUM": 1, "HIGH": 2, "CRITICAL": 3}
SENSITIVE = re.compile(r"password|passwd|secret|token|credential|authorization|cookie|private.?key|api.?key|webhook", re.I)
URL = re.compile(r"https?://[^\s<>\"']+", re.I)
ENUM = re.compile(r"[A-Z][A-Z0-9_]{0,79}\Z")


def safe_text(value, limit=2048):
    """Defense in depth; arbitrary payload/error text is never passed by default."""
    value = str(value)
    value = re.sub(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", "[REDACTED]", value, flags=re.S)
    # Withhold credential-shaped scalar text as a whole (quoted JSON, bearer
    # strings and free-text credentials included); never pretend regex DLP is
    # comprehensive. Operators must select only non-secret scalar fields.
    if SENSITIVE.search(value):
        return "[REDACTED sensitive text]"
    value = URL.sub("[URL REDACTED]", value)
    value = "".join(c if c >= " " and c != "\x7f" else " " for c in value)
    return value if len(value) <= limit else value[:limit] + " [TRUNCATED; inspect original audit record]"


def parse_time(value):
    if not isinstance(value, str):
        raise ValueError("Audit timestamp is missing or not ISO-8601")
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise ValueError("Audit timestamp is not valid ISO-8601") from None
    if dt.tzinfo is None:
        raise ValueError("Audit timestamp must include its UTC offset")
    return dt.astimezone(timezone.utc)


def iso(value):
    if value.tzinfo is None:
        raise ValueError("Timestamp must be timezone-aware")
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _scalar(payload, pointer):
    """Allowlist scalar leaves, not raw objects. Operators choose non-secret fields."""
    keys = [p.replace("~1", "/").replace("~0", "~") for p in pointer[1:].split("/")]
    if any(SENSITIVE.search(k) for k in keys):
        return "[REDACTED sensitive field]"
    value = payload
    for key in keys:
        if isinstance(value, dict) and key in value:
            value = value[key]
        elif isinstance(value, list) and key.isdigit() and int(key) < len(value):
            value = value[int(key)]
        else:
            return UNKNOWN
    if isinstance(value, (dict, list)):
        return "[STRUCTURED VALUE OMITTED; configure scalar child fields]"
    return "null" if value is None else safe_text(value)


def normalize_event(raw, config):
    if not isinstance(raw, dict):
        raise ValueError("Audit entry is not an object")
    for key in ("objectType", "operation", "status"):
        if not isinstance(raw.get(key), str) or not raw[key].strip():
            raise ValueError(f"Audit entry missing {key}; stopping rather than silently ignoring it")
        if not ENUM.fullmatch(raw[key].strip().upper()):
            raise ValueError(f"Audit entry has invalid {key}; refusing unsafe/unclassifiable metadata")
    for key in ("objectName", "startedBy", "eventId", "source"):
        if raw.get(key) is not None and not isinstance(raw[key], str):
            raise ValueError(f"Audit entry {key} must be text, not structured data")
    utc = parse_time(raw.get("timeOfLog"))
    payload = raw.get("payload")
    payload_note = "Only explicitly configured scalar fields are included."
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except ValueError:
            payload_note = "Payload is not JSON; withheld. Inspect original audit record."
            payload = {}
    if not isinstance(payload, dict):
        payload = {}
    if not payload and "not JSON" not in payload_note:
        payload_note = "Structured payload not recorded by source."
    # Include actor and the complete record in fallback/revision identity. The hash
    # is not a secret archive; raw payload is not persisted or printed.
    digest = hashlib.sha256(json.dumps(raw, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()
    actor = raw.get("startedBy") or UNKNOWN
    event = {
        "key": digest,
        "event_id": safe_text(raw.get("eventId") or "sha256:" + digest),
        "identity_note": "Source event ID" if raw.get("eventId") else "Fallback fingerprint (source supplied no ID)",
        "timestamp_utc": iso(utc),
        "timestamp_local": utc.astimezone(ZoneInfo(config["timezone"])).isoformat(),
        "object_type": raw["objectType"].strip().upper(),
        "operation": raw["operation"].strip().upper(),
        "status": raw["status"].strip().upper(),
        "object_name": safe_text(raw.get("objectName") or UNKNOWN),
        "actor_id": safe_text(actor),
        "actor_name": safe_text(config.get("actor_aliases", {}).get(actor, UNKNOWN)),
        "source": safe_text(raw.get("source") or UNKNOWN),
        "details": {safe_text(label): _scalar(payload, pointer) for label, pointer in config.get("detail_fields", {}).items()},
        "changes": [],
        "payload_note": payload_note,
        "error_note": "Error reported by source; inspect original audit record (free text withheld)." if raw.get("errorMessage") else "No error detail recorded.",
    }
    for field in config.get("change_fields", []):
        before, after = _scalar(payload, field["before"]), _scalar(payload, field["after"])
        if before != UNKNOWN or after != UNKNOWN:
            event["changes"].append({"field": safe_text(field["label"]), "before": before, "after": after})
    return event


def matched_rules(event, config, *, raw_object_name=None):
    found = []
    for r in config["rules"]:
        if not r["enabled"]:
            continue
        if all("*" in r[key] or event[field] in r[key] for key, field in
               (("object_types", "object_type"), ("operations", "operation"), ("statuses", "status"))):
            name = raw_object_name if raw_object_name is not None else event["object_name"]
            if any(fnmatchcase(name, pat) for pat in r.get("object_name_globs", ["*"])):
                found.append(r)
    return found


def make_alert(raw, config):
    event = normalize_event(raw, config)
    rules = matched_rules(event, config, raw_object_name=raw.get("objectName") or UNKNOWN)
    if not rules:
        return event, None
    severity = max((r["severity"] for r in rules), key=SEVERITIES.get)
    reasons = [r["id"] for r in rules]
    subject = f"[{safe_text(config['environment'], 80)}][{severity}] AIDP {event['object_type']} {event['operation']} | {event['status']}"
    lines = [subject, "", f"Environment: {safe_text(config['environment'])}",
             f"AIDP platform: {safe_text(config['aidp']['datalake_id'])}",
             f"Object type: {event['object_type']}", f"Object / deleted target: {event['object_name']}",
             f"Operation: {safe_text(event['operation'])}", f"Recorded outcome: {safe_text(event['status'])}",
             f"Initiating identity: {event['actor_id']}", f"Identity display name (configured alias): {event['actor_name']}",
             f"Time UTC: {event['timestamp_utc']}", f"Time local ({config['timezone']}): {event['timestamp_local']}",
             f"Source: {event['source']}", f"Event ID: {event['event_id']}",
             f"Identity basis: {event['identity_note']}", f"Revision fingerprint: {event['key']}",
             f"Matched rules: {safe_text(', '.join(reasons))}", "", "Recorded changes:"]
    if event["changes"]:
        lines.extend(f"- {f['field']}: {f['before']} -> {f['after']}" for f in event["changes"])
        lines.append("These are mapped audit fields, not an independently verified before/after state.")
    else:
        lines.append("NOT RECORDED / no configured before-after fields found. The previous state is not inferred.")
    lines.extend(["", "Selected audit details:"] + [f"- {k}: {v}" for k, v in event["details"].items()])
    lines.extend([event["payload_note"], event["error_note"], "",
                  "This reports the recorded operation and outcome. FAILED is an attempted action, not confirmation of deletion.",
                  "Correlate the event ID and timestamp in AIDP Audit Logs for full source evidence."])
    return event, {"event": event, "severity": severity, "rules": reasons, "subject": subject, "body": "\n".join(lines)}


def preview_events(raw_events, config, *, emit=print):
    """Always console-only: no state advancement, secret retrieval or delivery."""
    config = validate_config(config)
    alerts, seen = [], set()
    counts = Counter()
    fetched = 0
    for raw in raw_events:
        fetched += 1
        event, alert = make_alert(raw, config)
        counts[f"{event['object_type']}/{event['operation']}/{event['status']}"] += 1
        if alert and event["key"] not in seen:
            emit("[PREVIEW ONLY - NO EMAIL]\n" + alert["body"] + "\n")
            alerts.append(alert)
            seen.add(event["key"])
    emit(json.dumps({"mode": "preview", "fetched": fetched, "matched_unique": len(alerts),
                     "observed_event_types": dict(counts)}, sort_keys=True))
    return alerts
