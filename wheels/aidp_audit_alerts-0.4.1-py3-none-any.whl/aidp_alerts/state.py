"""Explicitly saved, single-writer checkpoints and notification outboxes.

State is stored in a kernel-readable workspace folder using file locks, fsync
and atomic replacement. The deployment must verify that the mount preserves these
semantics and survives cluster restarts. Only one monitoring worker is supported.
Malformed state is never silently reset. No cloud state client is used.
"""
from __future__ import annotations

from contextlib import contextmanager
from copy import deepcopy
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import tempfile
import threading
from typing import Any, Callable, ContextManager, Iterator, Protocol


DEFAULT_MAX_BYTES = 5 * 1024 * 1024
INITIAL_STATE = {"version": 1, "cursor": None, "events": {}, "deliveries": {}}


class StateError(RuntimeError):
    """State cannot be safely read or committed; processing must stop."""


class StateConflictError(StateError):
    """Another worker owns or changed the checkpoint."""


def _limit(value: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1024:
        raise ValueError("State max_bytes must be an integer of at least 1024.")
    return value


def _validate_data(value: Any) -> dict[str, Any]:
    if not isinstance(value, dict) or type(value.get("version")) is not int or value["version"] != 1:
        raise StateError("Unsupported or malformed state data; do not reset it automatically.")
    if not isinstance(value.get("events"), dict) or not isinstance(value.get("deliveries"), dict):
        raise StateError("Malformed state events/deliveries; manual investigation is required.")
    if "cursor" not in value:
        raise StateError("State cursor is missing; manual investigation is required.")
    return value


def _envelope(data: dict[str, Any], owner: dict[str, str] | None = None) -> dict[str, Any]:
    return {"format_version": 1, "lock": owner, "data": _validate_data(data)}


def _encode(document: dict[str, Any], max_bytes: int) -> bytes:
    try:
        result = json.dumps(document, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
    except (ValueError, TypeError, UnicodeError):
        raise StateError("State is not valid JSON; nothing was written.") from None
    if len(result) > max_bytes:
        raise StateError("State exceeds max_bytes; stop and increase capacity or archive safely.")
    return result


def _decode(raw: bytes, max_bytes: int) -> dict[str, Any]:
    if len(raw) > max_bytes:
        raise StateError("Existing state exceeds max_bytes; no changes were made.")
    def unique_object(pairs):
        value = {}
        for key, item in pairs:
            if key in value:
                raise ValueError("duplicate key")
            value[key] = item
        return value

    def reject_constant(value):
        raise ValueError("non-finite JSON number")

    try:
        document = json.loads(raw, object_pairs_hook=unique_object, parse_constant=reject_constant)
    except (ValueError, UnicodeError):
        raise StateError("State contains invalid JSON; manual investigation is required.") from None
    if not isinstance(document, dict) or type(document.get("format_version")) is not int or document["format_version"] != 1:
        raise StateError("Unsupported state envelope; no changes were made.")
    _validate_data(document.get("data"))
    if "lock" not in document:
        raise StateError("State ownership metadata is missing; no changes were made.")
    owner = document["lock"]
    if owner is not None and (
        not isinstance(owner, dict)
        or not isinstance(owner.get("owner"), str)
        or not owner["owner"]
        or not isinstance(owner.get("acquired_at"), str)
    ):
        raise StateError("State ownership metadata is malformed; no changes were made.")
    return document


class StateTransaction:
    """Mutate ``data`` then explicitly ``save`` after each durable transition."""

    def __init__(self, data: dict[str, Any], save: Callable[[dict[str, Any]], None]):
        self.data = deepcopy(data)
        self._save = save
        self._active = True

    def save(self) -> None:
        if not self._active:
            raise StateError("State transaction has already closed.")
        _validate_data(self.data)
        self._save(self.data)


class StateStore(Protocol):
    """Common backend contract consumed by the monitoring runner."""

    def locked(self) -> ContextManager[StateTransaction]: ...


class FileStateStore:
    """Atomic JSON + advisory lock file in a verified workspace filesystem.

    The containing directory must be private to the service account. On POSIX,
    newly created files use mode 0600; Windows requires an operator-managed ACL.
    """

    def __init__(self, path: str | os.PathLike[str], max_bytes: int = DEFAULT_MAX_BYTES):
        self.path = Path(path)
        self.max_bytes = _limit(max_bytes)

    def _save(self, data: dict[str, Any]) -> None:
        raw = _encode(_envelope(data), self.max_bytes)
        temp_name = None
        try:
            fd, temp_name = tempfile.mkstemp(prefix=self.path.name + ".", suffix=".tmp", dir=self.path.parent)
            with os.fdopen(fd, "wb") as stream:
                stream.write(raw)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temp_name, self.path)
            temp_name = None
            if os.name != "nt":
                directory_fd = os.open(self.path.parent, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
        except OSError:
            raise StateError("Local state commit failed; stop processing and inspect storage.") from None
        finally:
            if temp_name is not None:
                # Only the temporary file created by this save is removed.
                try:
                    os.unlink(temp_name)
                except OSError:
                    raise StateError("Temporary state cleanup failed; inspect the private state directory.") from None

    @contextmanager
    def locked(self) -> Iterator[StateTransaction]:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        lock_path = self.path.with_name(self.path.name + ".lock")
        fd = os.open(lock_path, os.O_RDWR | os.O_CREAT, 0o600)
        acquired = False
        transaction = None
        try:
            if os.name == "nt":
                import msvcrt
                if os.fstat(fd).st_size == 0:
                    os.write(fd, b"\0")
                os.lseek(fd, 0, os.SEEK_SET)
                try:
                    msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)
                except OSError:
                    raise StateConflictError("Local state is locked by another worker.") from None
            else:
                import fcntl
                try:
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError:
                    raise StateConflictError("Local state is locked by another worker.") from None
            acquired = True
            if self.path.exists():
                try:
                    with self.path.open("rb") as stream:
                        document = _decode(stream.read(self.max_bytes + 1), self.max_bytes)
                except OSError:
                    raise StateError("Local state cannot be read; no reset was performed.") from None
                if document["lock"] is not None:
                    raise StateError("Unexpected ownership metadata in file state; investigate before using this checkpoint.")
                data = document["data"]
            else:
                data = deepcopy(INITIAL_STATE)
            transaction = StateTransaction(data, self._save)
            yield transaction
        finally:
            if transaction is not None:
                transaction._active = False
            if acquired:
                if os.name == "nt":
                    import msvcrt
                    os.lseek(fd, 0, os.SEEK_SET)
                    msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
                else:
                    import fcntl
                    fcntl.flock(fd, fcntl.LOCK_UN)
            os.close(fd)


class MemoryStateStore:
    """Process-local state for offline tests only; never production delivery."""

    def __init__(self):
        self.data = deepcopy(INITIAL_STATE)
        self._lock = threading.Lock()

    @contextmanager
    def locked(self) -> Iterator[StateTransaction]:
        if not self._lock.acquire(blocking=False):
            raise StateConflictError("Memory state is already locked.")

        def save(data: dict[str, Any]) -> None:
            _encode(_envelope(data), DEFAULT_MAX_BYTES)
            self.data = deepcopy(data)

        transaction = StateTransaction(self.data, save)
        try:
            yield transaction
        finally:
            transaction._active = False
            self._lock.release()


def check_state_storage(path):
    """Probe the target folder without touching the configured checkpoint.

    This verifies write/read/replace and same-host lock exclusion only. It cannot
    certify cluster-restart persistence or lock coherence across different hosts.
    """
    target = Path(path)
    if not target.name or target.exists() and not target.is_file():
        raise StateError("Checkpoint path must name a file, not a directory.")
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        probe_dir = Path(tempfile.mkdtemp(prefix=".aidp-state-probe-", dir=target.parent))
    except OSError:
        raise StateError("Workspace checkpoint directory cannot be created or written.") from None
    probe = probe_dir / "probe.json"
    try:
        store = FileStateStore(probe)
        with store.locked() as tx:
            tx.save()
            tx.data["cursor"] = "probe-atomic-replace"
            tx.save()
            try:
                with FileStateStore(probe).locked():
                    raise StateError("Workspace filesystem does not enforce exclusive file locking.")
            except StateConflictError:
                pass
        with FileStateStore(probe).locked() as restored:
            if restored.data["cursor"] != "probe-atomic-replace":
                raise StateError("Workspace checkpoint read-after-replace failed.")
        return {"checkpoint_path": str(target.resolve()), "write_read_replace": True,
                "same_host_exclusive_lock": True, "restart_persistence_verified": False}
    except OSError:
        raise StateError("Workspace checkpoint filesystem probe failed; no checkpoint was changed.") from None
    finally:
        # Remove only this invocation's two known probe files and empty directory.
        for generated in (probe, probe.with_name("probe.json.lock")):
            generated.unlink(missing_ok=True)
        probe_dir.rmdir()
